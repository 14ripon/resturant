$(document).ready(function(){

	// preloader
	$(window).on("load", function(){
		$(".preloader").fadeOut();
	});

	// search box icon of menu
	$("#search-box-btn").click(function(){
		$("#menu-search-box").fadeToggle(1000);
	});


	// Mobile Menu
	$('.sidebarBtn').click(function(){
		$('.sidebar').toggleClass('active');
		$('.sidebarBtn').toggleClass('toggle');
	})

	//reservation controls
	$(".button-popup").click(function()
	{
		$(".window-popup").show(300);
	});
	
	$(".button-popup-close").click(function()
	{
		$(".window-popup").hide(300);
	});

	// Menu page collapse button
	$('.main-btn').click(function(){
		$('.main-btn').toggleClass('main-btn-active');
	})
	$('.main-btn2').click(function(){
		$('.main-btn2').toggleClass('main-btn-active2');
	})
	$('.main-btn3').click(function(){
		$('.main-btn3').toggleClass('main-btn-active3');
	})
	$('.main-btn4').click(function(){
		$('.main-btn4').toggleClass('main-btn-active4');
	})
	$('.main-btn5').click(function(){
		$('.main-btn5').toggleClass('main-btn-active5');
	})




	
});
